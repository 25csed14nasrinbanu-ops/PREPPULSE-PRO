import { UserProgress, QuizResult, MockInterviewResult } from '../types';

const STORAGE_KEY = 'preppulse_user_progress_v1';

const defaultProgress: UserProgress = {
  quizzesCompleted: 0,
  mockInterviewsCompleted: 0,
  totalQuestionsAnswered: 0,
  totalCorrectAnswers: 0,
  streakDays: 1,
  lastActiveDate: new Date().toISOString().slice(0, 10),
  bookmarkedQuestionIds: [],
  quizHistory: [],
  mockHistory: []
};

export function loadUserProgress(): UserProgress {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) return defaultProgress;
    const parsed = JSON.parse(data);

    // Calculate daily streak
    const today = new Date().toISOString().slice(0, 10);
    const lastActive = parsed.lastActiveDate || today;

    if (lastActive !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
      if (lastActive === yesterday) {
        parsed.streakDays = (parsed.streakDays || 1) + 1;
      } else {
        parsed.streakDays = 1;
      }
      parsed.lastActiveDate = today;
      saveUserProgress(parsed);
    }

    return { ...defaultProgress, ...parsed };
  } catch (e) {
    console.error('Error loading user progress:', e);
    return defaultProgress;
  }
}

export function saveUserProgress(progress: UserProgress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.error('Error saving user progress:', e);
  }
}

export function saveQuizResult(result: QuizResult): UserProgress {
  const current = loadUserProgress();
  const correctCount = result.answers.filter(a => a.isCorrect).length;

  const updated: UserProgress = {
    ...current,
    quizzesCompleted: current.quizzesCompleted + 1,
    totalQuestionsAnswered: current.totalQuestionsAnswered + result.totalQuestions,
    totalCorrectAnswers: current.totalCorrectAnswers + correctCount,
    quizHistory: [result, ...current.quizHistory]
  };

  saveUserProgress(updated);
  return updated;
}

export function saveMockInterviewResult(result: MockInterviewResult): UserProgress {
  const current = loadUserProgress();

  const updated: UserProgress = {
    ...current,
    mockInterviewsCompleted: current.mockInterviewsCompleted + 1,
    mockHistory: [result, ...current.mockHistory]
  };

  saveUserProgress(updated);
  return updated;
}

export function toggleBookmarkQuestion(questionId: string): { isBookmarked: boolean; progress: UserProgress } {
  const current = loadUserProgress();
  const exists = current.bookmarkedQuestionIds.includes(questionId);

  const updatedBookmarks = exists
    ? current.bookmarkedQuestionIds.filter(id => id !== questionId)
    : [...current.bookmarkedQuestionIds, questionId];

  const updated: UserProgress = {
    ...current,
    bookmarkedQuestionIds: updatedBookmarks
  };

  saveUserProgress(updated);
  return { isBookmarked: !exists, progress: updated };
}

export function resetUserProgress(): UserProgress {
  saveUserProgress(defaultProgress);
  return defaultProgress;
}
