import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { MCQQuizView } from './components/MCQQuizView';
import { MockInterviewView } from './components/MockInterviewView';
import { QuestionBankView } from './components/QuestionBankView';
import { CheatSheetsView } from './components/CheatSheetsView';
import { PDFExporter } from './components/PDFExporter';
import { loadUserProgress } from './utils/storage';
import { UserProgress, ActiveTab } from './types';
import { Sparkles, Download } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [progress, setProgress] = useState<UserProgress>(loadUserProgress());
  const [isPDFModalOpen, setIsPDFModalOpen] = useState<boolean>(false);

  const refreshProgress = () => {
    setProgress(loadUserProgress());
  };

  useEffect(() => {
    refreshProgress();
  }, [activeTab]);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Sticky Header Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        streakDays={progress.streakDays || 1}
        onOpenPDFModal={() => setIsPDFModalOpen(true)}
      />

      {/* Main Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            progress={progress}
            onSelectTab={setActiveTab}
            onRefreshProgress={refreshProgress}
          />
        )}

        {activeTab === 'mcq' && (
          <MCQQuizView onQuizCompleted={refreshProgress} />
        )}

        {activeTab === 'mock' && (
          <MockInterviewView onInterviewCompleted={refreshProgress} />
        )}

        {activeTab === 'bank' && (
          <QuestionBankView />
        )}

        {activeTab === 'cheatsheets' && (
          <CheatSheetsView />
        )}
      </main>

      {/* PDF Export Modal */}
      <PDFExporter
        isOpen={isPDFModalOpen}
        onClose={() => setIsPDFModalOpen(false)}
      />

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 text-xs py-8 border-t border-slate-800 mt-12 print:hidden font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <div className="flex items-center justify-center sm:justify-start space-x-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="font-serif text-sm font-bold uppercase tracking-wider text-white">PrepPulse Platform</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Interactive Interview Preparation • MCQs • Mock Interview Simulator • Big-O & SQL Cheat Sheets
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => setIsPDFModalOpen(true)}
              className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-white px-3.5 py-2 rounded-lg font-bold transition-all cursor-pointer border border-slate-700"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              <span>Export Study PDF</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
