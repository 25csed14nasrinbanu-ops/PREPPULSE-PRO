export type CategoryType = 'all' | 'technical' | 'hr' | 'aptitude' | 'mcq';

export type ActiveTab = 'dashboard' | 'mcq' | 'mock' | 'bank' | 'cheatsheets';

export type DifficultyLevel = 'all' | 'easy' | 'medium' | 'hard';

export interface MCQQuestion {
  id: string;
  category: CategoryType;
  topic: string; // e.g. "Operating Systems", "Data Structures", "System Design", "SQL", "Quantitative Aptitude"
  difficulty: 'easy' | 'medium' | 'hard';
  question: string;
  codeSnippet?: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  tags: string[];
}

export interface InterviewQuestion {
  id: string;
  category: CategoryType;
  topic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  question: string;
  scenarioContext?: string;
  answerHint: string;
  keyPoints: string[];
  sampleAnswer: string;
  codeExample?: string;
  followUpQuestions?: string[];
}

export interface QuizResult {
  id: string;
  date: string;
  category: string;
  topic: string;
  difficulty: string;
  totalQuestions: number;
  score: number;
  percentage: number;
  timeSpentSeconds: number;
  answers: {
    questionId: string;
    selectedIndex: number;
    isCorrect: boolean;
  }[];
}

export interface MockInterviewResult {
  id: string;
  date: string;
  roleTitle: string;
  category: string;
  difficulty: string;
  totalQuestions: number;
  overallScore: number; // 1-10 scale
  timeSpentSeconds: number;
  evaluations: {
    questionId: string;
    question: string;
    userResponse: string;
    score: number;
    strengths: string[];
    areasForImprovement: string[];
    idealAnswerSummary: string;
  }[];
}

export interface UserProgress {
  quizzesCompleted: number;
  mockInterviewsCompleted: number;
  totalQuestionsAnswered: number;
  totalCorrectAnswers: number;
  streakDays: number;
  lastActiveDate: string;
  bookmarkedQuestionIds: string[];
  quizHistory: QuizResult[];
  mockHistory: MockInterviewResult[];
}

export interface CheatSheetItem {
  id: string;
  title: string;
  category: string;
  topic: string;
  summary: string;
  sections: {
    title: string;
    content: string;
    code?: string;
    keyTakeaways?: string[];
  }[];
}
