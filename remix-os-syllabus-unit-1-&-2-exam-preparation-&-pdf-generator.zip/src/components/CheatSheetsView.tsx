import React, { useState } from 'react';
import { cheatSheets } from '../data/cheatSheets';
import { FileCode2, Copy, Check, Sparkles, BookOpen } from 'lucide-react';

export function CheatSheetsView() {
  const [selectedSheetId, setSelectedSheetId] = useState<string>(cheatSheets[0].id);
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<number | null>(null);

  const activeSheet = cheatSheets.find(s => s.id === selectedSheetId) || cheatSheets[0];

  const handleCopy = (code: string, idx: number) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeIndex(idx);
    setTimeout(() => setCopiedCodeIndex(null), 2000);
  };

  return (
    <div className="space-y-6 font-sans animate-fade-in max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold border border-indigo-200">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Interview Reference Cheat Sheets</span>
            </div>
            <h2 className="text-xl font-extrabold text-slate-900 font-serif tracking-tight mt-1">
              Quick Preparation & Formula Cheat Sheets
            </h2>
            <p className="text-xs text-slate-500">
              High-density reference guides for Big-O complexities, SQL window functions, System Design blueprints, and behavioral formulas.
            </p>
          </div>
        </div>

        {/* Cheat Sheet Selector Tabs */}
        <div className="flex flex-wrap gap-2">
          {cheatSheets.map((sheet) => {
            const isActive = sheet.id === selectedSheetId;
            return (
              <button
                key={sheet.id}
                onClick={() => setSelectedSheetId(sheet.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <FileCode2 className="w-3.5 h-3.5" />
                <span>{sheet.title}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Cheat Sheet Content */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-sm">
        <div className="border-b border-slate-100 pb-4 space-y-1">
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full">
            {activeSheet.topic}
          </span>
          <h3 className="text-2xl font-bold text-slate-900 font-serif">{activeSheet.title}</h3>
          <p className="text-xs text-slate-600 leading-relaxed">{activeSheet.summary}</p>
        </div>

        <div className="space-y-6">
          {activeSheet.sections.map((sec, idx) => (
            <div key={idx} className="space-y-3">
              <h4 className="text-base font-bold text-slate-900 flex items-center space-x-2">
                <BookOpen className="w-4 h-4 text-indigo-600" />
                <span>{sec.title}</span>
              </h4>

              <p className="text-xs text-slate-600 leading-relaxed">{sec.content}</p>

              {sec.code && (
                <div className="relative group">
                  <button
                    onClick={() => handleCopy(sec.code!, idx)}
                    className="absolute right-3 top-3 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center space-x-1 transition-all cursor-pointer"
                  >
                    {copiedCodeIndex === idx ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>

                  <pre className="bg-slate-900 text-slate-100 p-4 rounded-2xl text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800 shadow-inner">
                    <code>{sec.code}</code>
                  </pre>
                </div>
              )}

              {sec.keyTakeaways && sec.keyTakeaways.length > 0 && (
                <div className="bg-indigo-50/60 border border-indigo-200/80 p-4 rounded-xl text-xs space-y-1">
                  <span className="font-bold text-indigo-900 block">Key Interview Takeaways:</span>
                  <ul className="list-disc pl-4 text-slate-700 space-y-0.5">
                    {sec.keyTakeaways.map((kt, kIdx) => (
                      <li key={kIdx}>{kt}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
