import React, { useState, useEffect } from 'react';
import { mcqQuestions } from '../data/mcqQuestions';
import { MCQQuestion, QuizResult } from '../types';
import { saveQuizResult, toggleBookmarkQuestion } from '../utils/storage';
import {
  CheckCircle2,
  XCircle,
  Clock,
  HelpCircle,
  ArrowRight,
  RotateCcw,
  Award,
  Bookmark,
  Sparkles,
  Filter,
  Check,
  AlertTriangle,
  Lightbulb
} from 'lucide-react';

interface MCQQuizViewProps {
  onQuizCompleted?: () => void;
}

export function MCQQuizView({ onQuizCompleted }: MCQQuizViewProps) {
  // Quiz Configuration State
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTopic, setSelectedTopic] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [timerMode, setTimerMode] = useState<number>(0); // 0 = no timer, 30 = 30s/q, 60 = 60s/q

  // Quiz Execution State
  const [quizStarted, setQuizStarted] = useState<boolean>(false);
  const [activeQuestions, setActiveQuestions] = useState<MCQQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [timeSpent, setTimeSpent] = useState<number>(0);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [finalResult, setFinalResult] = useState<QuizResult | null>(null);

  // Extract unique topics from dataset
  const availableTopics = Array.from(new Set(mcqQuestions.map(q => q.topic)));

  // Timer Countdown Effect
  useEffect(() => {
    let timer: any = null;
    if (quizStarted && !quizSubmitted) {
      timer = setInterval(() => {
        setTimeSpent(prev => prev + 1);
        if (timerMode > 0) {
          setTimeLeft(prev => {
            if (prev <= 1) {
              handleNextQuestion();
              return timerMode;
            }
            return prev - 1;
          });
        }
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [quizStarted, quizSubmitted, currentIndex, timerMode]);

  // Start Quiz Handler
  const handleStartQuiz = () => {
    let filtered = [...mcqQuestions];

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(q => q.category === selectedCategory);
    }
    if (selectedTopic !== 'all') {
      filtered = filtered.filter(q => q.topic === selectedTopic);
    }
    if (selectedDifficulty !== 'all') {
      filtered = filtered.filter(q => q.difficulty === selectedDifficulty);
    }

    // Shuffle and pick desired count
    const shuffled = filtered.sort(() => 0.5 - Math.random()).slice(0, questionCount);

    if (shuffled.length === 0) {
      alert('No questions match the selected filters. Please adjust category or topic.');
      return;
    }

    setActiveQuestions(shuffled);
    setCurrentIndex(0);
    setUserAnswers({});
    setQuizStarted(true);
    setQuizSubmitted(false);
    setFinalResult(null);
    setTimeSpent(0);
    if (timerMode > 0) {
      setTimeLeft(timerMode);
    }
  };

  // Select Option Handler
  const handleSelectOption = (optionIndex: number) => {
    if (quizSubmitted) return;
    setUserAnswers(prev => ({
      ...prev,
      [currentIndex]: optionIndex
    }));
  };

  // Next / Skip Handler
  const handleNextQuestion = () => {
    if (currentIndex < activeQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      if (timerMode > 0) setTimeLeft(timerMode);
    } else {
      handleSubmitQuiz();
    }
  };

  // Submit Quiz Handler
  const handleSubmitQuiz = () => {
    let score = 0;
    const answerDetails = activeQuestions.map((q, idx) => {
      const selectedIndex = userAnswers[idx] ?? -1;
      const isCorrect = selectedIndex === q.correctAnswerIndex;
      if (isCorrect) score++;
      return {
        questionId: q.id,
        selectedIndex,
        isCorrect
      };
    });

    const total = activeQuestions.length;
    const percentage = Math.round((score / total) * 100);

    const result: QuizResult = {
      id: 'quiz-' + Date.now(),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      category: selectedCategory,
      topic: selectedTopic === 'all' ? 'Mixed Topics' : selectedTopic,
      difficulty: selectedDifficulty,
      totalQuestions: total,
      score,
      percentage,
      timeSpentSeconds: timeSpent,
      answers: answerDetails
    };

    saveQuizResult(result);
    setFinalResult(result);
    setQuizSubmitted(true);
    if (onQuizCompleted) onQuizCompleted();
  };

  // Bookmark toggle
  const handleToggleBookmark = (qId: string) => {
    const res = toggleBookmarkQuestion(qId);
    if (res.isBookmarked) {
      setBookmarkedIds(prev => [...prev, qId]);
    } else {
      setBookmarkedIds(prev => prev.filter(id => id !== qId));
    }
  };

  const currentQ = activeQuestions[currentIndex];

  return (
    <div className="space-y-6 font-sans animate-fade-in max-w-4xl mx-auto">
      {/* SECTION 1: QUIZ CONFIGURATION SCREEN */}
      {!quizStarted && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="space-y-2 border-b border-slate-100 pb-4">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold border border-indigo-200">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Topic-Wise MCQ Practice Engine</span>
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight font-serif">Configure Practice Quiz</h2>
            <p className="text-xs text-slate-500">
              Select topic, difficulty level, and question volume to start an interactive timed practice session.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Category Filter */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setSelectedTopic('all');
                }}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Categories (Technical, HR, Aptitude)</option>
                <option value="technical">Technical Questions</option>
                <option value="hr">HR & Behavioral</option>
                <option value="aptitude">Quantitative Aptitude & Reasoning</option>
              </select>
            </div>

            {/* Topic Filter */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Topic</label>
              <select
                value={selectedTopic}
                onChange={(e) => setSelectedTopic(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Topics</option>
                {availableTopics.map((top) => (
                  <option key={top} value={top}>{top}</option>
                ))}
              </select>
            </div>

            {/* Difficulty Level */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Difficulty Level</label>
              <div className="grid grid-cols-4 gap-2">
                {['all', 'easy', 'medium', 'hard'].map((diff) => (
                  <button
                    key={diff}
                    onClick={() => setSelectedDifficulty(diff)}
                    className={`py-2 rounded-xl text-xs font-bold uppercase tracking-wider border transition-all cursor-pointer ${
                      selectedDifficulty === diff
                        ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            {/* Question Count */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Question Volume</label>
              <div className="grid grid-cols-4 gap-2">
                {[5, 10, 15, 20].map((cnt) => (
                  <button
                    key={cnt}
                    onClick={() => setQuestionCount(cnt)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      questionCount === cnt
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {cnt} Questions
                  </button>
                ))}
              </div>
            </div>

            {/* Timer Option */}
            <div className="sm:col-span-2 space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Timer Mode</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: 0, label: 'No Timer (Untimed Mode)' },
                  { value: 30, label: '30s Per Question (Speed)' },
                  { value: 60, label: '60s Per Question (Standard)' }
                ].map((tm) => (
                  <button
                    key={tm.value}
                    onClick={() => setTimerMode(tm.value)}
                    className={`p-3 rounded-xl text-xs font-semibold border text-left transition-all cursor-pointer ${
                      timerMode === tm.value
                        ? 'bg-indigo-50 text-indigo-700 border-indigo-300 font-bold'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {tm.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              onClick={handleStartQuiz}
              className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-3 rounded-xl transition-all shadow-md shadow-indigo-600/30 cursor-pointer text-sm"
            >
              <span>Start Practice Quiz</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* SECTION 2: LIVE QUIZ INTERFACE */}
      {quizStarted && !quizSubmitted && currentQ && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-sm">
          {/* Header Progress Bar */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center space-x-3">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-200">
                Question {currentIndex + 1} of {activeQuestions.length}
              </span>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                Topic: {currentQ.topic}
              </span>
            </div>

            <div className="flex items-center space-x-3">
              {/* Timer indicator */}
              {timerMode > 0 && (
                <div className={`flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold border ${
                  timeLeft <= 10 ? 'bg-red-50 text-red-600 border-red-200 animate-pulse' : 'bg-slate-100 text-slate-700 border-slate-200'
                }`}>
                  <Clock className="w-3.5 h-3.5" />
                  <span>{timeLeft}s</span>
                </div>
              )}

              {/* Bookmark Button */}
              <button
                onClick={() => handleToggleBookmark(currentQ.id)}
                className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                  bookmarkedIds.includes(currentQ.id)
                    ? 'bg-amber-50 text-amber-600 border-amber-300'
                    : 'bg-slate-50 text-slate-400 border-slate-200 hover:text-slate-700'
                }`}
                title="Save Question"
              >
                <Bookmark className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Progress bar visual line */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-indigo-600 h-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / activeQuestions.length) * 100}%` }}
            />
          </div>

          {/* Question Prompt */}
          <div className="space-y-4">
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
              {currentQ.question}
            </h3>

            {currentQ.codeSnippet && (
              <pre className="bg-slate-900 text-slate-100 p-4 rounded-xl text-xs font-mono overflow-x-auto leading-relaxed">
                <code>{currentQ.codeSnippet}</code>
              </pre>
            )}
          </div>

          {/* Options Grid */}
          <div className="space-y-3">
            {currentQ.options.map((option, optIdx) => {
              const isSelected = userAnswers[currentIndex] === optIdx;

              return (
                <button
                  key={optIdx}
                  onClick={() => handleSelectOption(optIdx)}
                  className={`w-full p-4 rounded-xl text-left border transition-all cursor-pointer flex items-center justify-between text-xs sm:text-sm ${
                    isSelected
                      ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 font-bold shadow-xs'
                      : 'bg-slate-50/80 border-slate-200 hover:border-slate-300 text-slate-800 hover:bg-slate-100/80'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                      isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {String.fromCharCode(65 + optIdx)}
                    </span>
                    <span>{option}</span>
                  </div>

                  {isSelected && <Check className="w-4 h-4 text-indigo-600 shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Instant Explanation Box (if user answered) */}
          {userAnswers[currentIndex] !== undefined && (
            <div className="bg-indigo-50/60 border border-indigo-200 rounded-xl p-4 space-y-2 animate-fade-in text-xs">
              <div className="flex items-center space-x-2 font-bold text-indigo-900">
                <Lightbulb className="w-4 h-4 text-amber-500" />
                <span>Explanation & Concept Breakdown</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                {currentQ.explanation}
              </p>
            </div>
          )}

          {/* Controls Footer */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={() => {
                if (confirm('Cancel current quiz session?')) {
                  setQuizStarted(false);
                }
              }}
              className="text-xs text-slate-400 hover:text-slate-600 font-semibold cursor-pointer"
            >
              Exit Quiz
            </button>

            <button
              onClick={handleNextQuestion}
              className="flex items-center space-x-2 bg-slate-900 hover:bg-slate-800 text-white font-bold px-5 py-2.5 rounded-xl transition-all cursor-pointer text-xs"
            >
              <span>{currentIndex === activeQuestions.length - 1 ? 'Finish & View Score' : 'Next Question'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* SECTION 3: QUIZ RESULT & PERFORMANCE REPORT */}
      {quizSubmitted && finalResult && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-8 shadow-sm">
          {/* Header Badge */}
          <div className="text-center space-y-3 pb-6 border-b border-slate-100">
            <div className="w-16 h-16 bg-gradient-to-tr from-indigo-600 to-blue-600 rounded-2xl flex items-center justify-center text-white mx-auto shadow-lg shadow-indigo-500/20">
              <Award className="w-8 h-8 text-amber-300" />
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-serif">
              Quiz Completed!
            </h2>

            <div className="flex items-center justify-center space-x-2">
              <span className={`text-2xl font-black ${
                finalResult.percentage >= 80 ? 'text-emerald-600' : finalResult.percentage >= 60 ? 'text-indigo-600' : 'text-amber-600'
              }`}>
                {finalResult.percentage}% Score
              </span>
              <span className="text-xs text-slate-500 font-semibold">
                ({finalResult.score} / {finalResult.totalQuestions} Correct)
              </span>
            </div>

            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {finalResult.percentage >= 80
                ? 'Outstanding performance! You have demonstrated strong subject mastery.'
                : finalResult.percentage >= 60
                ? 'Good job! Review the explanations below to refine tricky concepts.'
                : 'Keep practicing! Focus on reviewing missed topics to improve accuracy.'}
            </p>
          </div>

          {/* Detailed Question Review */}
          <div className="space-y-4">
            <h3 className="text-base font-bold text-slate-900">Question-by-Question Detailed Review</h3>

            <div className="space-y-4">
              {activeQuestions.map((q, idx) => {
                const userChoice = userAnswers[idx];
                const isCorrect = userChoice === q.correctAnswerIndex;

                return (
                  <div
                    key={q.id}
                    className={`p-5 rounded-2xl border space-y-3 ${
                      isCorrect ? 'bg-emerald-50/40 border-emerald-200' : 'bg-red-50/30 border-red-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start space-x-2">
                        {isCorrect ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                        ) : (
                          <XCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                        )}
                        <div>
                          <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-500">
                            Question {idx + 1} • {q.topic}
                          </span>
                          <h4 className="text-sm font-bold text-slate-900 mt-0.5">{q.question}</h4>
                        </div>
                      </div>
                    </div>

                    {/* Options status */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      {q.options.map((opt, oIdx) => {
                        const isChosen = userChoice === oIdx;
                        const isAnswer = q.correctAnswerIndex === oIdx;

                        return (
                          <div
                            key={oIdx}
                            className={`p-2.5 rounded-lg border font-medium ${
                              isAnswer
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-300 font-bold'
                                : isChosen
                                ? 'bg-red-100 text-red-900 border-red-300'
                                : 'bg-white text-slate-600 border-slate-200'
                            }`}
                          >
                            <span>{String.fromCharCode(65 + oIdx)}. {opt}</span>
                            {isAnswer && <span className="ml-2 text-[10px] uppercase font-extrabold text-emerald-700">(Correct Answer)</span>}
                            {isChosen && !isAnswer && <span className="ml-2 text-[10px] uppercase font-extrabold text-red-700">(Your Answer)</span>}
                          </div>
                        );
                      })}
                    </div>

                    {/* Explanation */}
                    <div className="bg-white/80 p-3 rounded-xl border border-slate-200/80 text-xs text-slate-700 space-y-1">
                      <span className="font-bold text-slate-900 block">Explanation:</span>
                      <p>{q.explanation}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <button
              onClick={() => {
                setQuizStarted(false);
                setQuizSubmitted(false);
              }}
              className="flex items-center space-x-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-4 py-2.5 rounded-xl text-xs cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Configure New Quiz</span>
            </button>

            <button
              onClick={handleStartQuiz}
              className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs cursor-pointer shadow-md shadow-indigo-600/30"
            >
              <span>Retake Quiz</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
