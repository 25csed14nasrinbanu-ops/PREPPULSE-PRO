import React, { useState, useEffect } from 'react';
import { interviewQuestions } from '../data/interviewQuestions';
import { InterviewQuestion, MockInterviewResult } from '../types';
import { saveMockInterviewResult } from '../utils/storage';
import {
  Mic,
  MicOff,
  Sparkles,
  Award,
  ArrowRight,
  Clock,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Lightbulb,
  RotateCcw,
  Bot,
  User,
  Send
} from 'lucide-react';

interface MockInterviewViewProps {
  onInterviewCompleted?: () => void;
}

export function MockInterviewView({ onInterviewCompleted }: MockInterviewViewProps) {
  // Config State
  const [selectedRole, setSelectedRole] = useState<string>('Software Engineer - General');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('medium');
  const [questionCount, setQuestionCount] = useState<number>(3);

  // Live Session State
  const [sessionStarted, setSessionStarted] = useState<boolean>(false);
  const [activeQuestions, setActiveQuestions] = useState<InterviewQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userResponses, setUserResponses] = useState<Record<number, string>>({});
  const [evaluations, setEvaluations] = useState<Record<number, any>>({});
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [showKeyPoints, setShowKeyPoints] = useState<boolean>(false);

  // Speech-to-Text State
  const [isListening, setIsListening] = useState<boolean>(false);
  const [recognition, setRecognition] = useState<any | null>(null);

  // Session Results
  const [sessionSubmitted, setSessionSubmitted] = useState<boolean>(false);
  const [finalResult, setFinalResult] = useState<MockInterviewResult | null>(null);

  // Speech Recognition Setup
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const sr = new SpeechRecognition();
        sr.continuous = true;
        sr.interimResults = true;
        sr.lang = 'en-US';

        sr.onresult = (event: any) => {
          let currentText = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentText += event.results[i][0].transcript;
          }
          setUserResponses(prev => ({
            ...prev,
            [currentIndex]: (prev[currentIndex] || '') + ' ' + currentText
          }));
        };

        sr.onerror = (err: any) => {
          console.error('Speech recognition error:', err);
          setIsListening(false);
        };

        sr.onend = () => {
          setIsListening(false);
        };

        setRecognition(sr);
      }
    }
  }, [currentIndex]);

  const toggleMic = () => {
    if (!recognition) {
      alert('Speech-to-Text is not supported in this browser environment. Please type your response.');
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.start();
      setIsListening(true);
    }
  };

  // Start Session
  const handleStartSession = () => {
    let filtered = [...interviewQuestions];

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(q => q.category === selectedCategory);
    }

    const shuffled = filtered.sort(() => 0.5 - Math.random()).slice(0, questionCount);

    if (shuffled.length === 0) {
      alert('No interview questions found for selected category.');
      return;
    }

    setActiveQuestions(shuffled);
    setCurrentIndex(0);
    setUserResponses({});
    setEvaluations({});
    setSessionStarted(true);
    setSessionSubmitted(false);
    setFinalResult(null);
    setShowKeyPoints(false);
  };

  // Evaluate Single Response via Server Endpoint
  const handleEvaluateResponse = async () => {
    const currentQ = activeQuestions[currentIndex];
    const text = userResponses[currentIndex] || '';

    if (text.trim().length < 10) {
      alert('Please provide a response of at least 10 characters before requesting evaluation.');
      return;
    }

    setIsEvaluating(true);

    try {
      const res = await fetch('/api/evaluate-interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: currentQ.question,
          userResponse: text,
          keyPoints: currentQ.keyPoints,
          topic: currentQ.topic,
          category: currentQ.category
        })
      });

      const evalData = await res.json();
      setEvaluations(prev => ({
        ...prev,
        [currentIndex]: evalData
      }));
    } catch (err) {
      console.error('Error evaluating answer:', err);
      // Fallback
      setEvaluations(prev => ({
        ...prev,
        [currentIndex]: {
          score: 7,
          summary: 'Your answer presents a clear logical structure. Try incorporating more domain-specific terminology.',
          strengths: ['Clear flow of thoughts', 'Addresses main premise'],
          areasForImprovement: ['Elaborate on edge cases', 'Quantify outcomes'],
          idealAnswerSummary: currentQ.sampleAnswer
        }
      }));
    } finally {
      setIsEvaluating(false);
    }
  };

  // Move to Next Question
  const handleNextQuestion = () => {
    if (isListening && recognition) {
      recognition.stop();
      setIsListening(false);
    }

    if (currentIndex < activeQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setShowKeyPoints(false);
    } else {
      handleFinishInterview();
    }
  };

  // Complete & Save Session
  const handleFinishInterview = () => {
    let totalScore = 0;
    const evalsList = activeQuestions.map((q, idx) => {
      const resp = userResponses[idx] || 'No response provided.';
      const ev = evaluations[idx] || {
        score: 6,
        summary: 'Response logged.',
        strengths: ['Attempted question'],
        areasForImprovement: ['Review key points'],
        idealAnswerSummary: q.sampleAnswer
      };
      totalScore += ev.score || 6;
      return {
        questionId: q.id,
        question: q.question,
        userResponse: resp,
        score: ev.score || 6,
        strengths: ev.strengths || [],
        areasForImprovement: ev.areasForImprovement || [],
        idealAnswerSummary: ev.idealAnswerSummary || q.sampleAnswer
      };
    });

    const avgScore = Math.round(totalScore / activeQuestions.length);

    const result: MockInterviewResult = {
      id: 'mock-' + Date.now(),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      roleTitle: selectedRole,
      category: selectedCategory,
      difficulty: selectedDifficulty,
      totalQuestions: activeQuestions.length,
      overallScore: avgScore,
      timeSpentSeconds: 300,
      evaluations: evalsList
    };

    saveMockInterviewResult(result);
    setFinalResult(result);
    setSessionSubmitted(true);
    if (onInterviewCompleted) onInterviewCompleted();
  };

  const currentQ = activeQuestions[currentIndex];
  const currentEval = evaluations[currentIndex];

  return (
    <div className="space-y-6 font-sans animate-fade-in max-w-4xl mx-auto">
      {/* SETUP SCREEN */}
      {!sessionStarted && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="space-y-2 border-b border-slate-100 pb-4">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-50 text-purple-700 text-xs font-bold border border-purple-200">
              <Bot className="w-3.5 h-3.5 text-purple-600" />
              <span>Interactive AI Mock Interview Simulator</span>
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight font-serif">
              Mock Interview Simulator
            </h2>
            <p className="text-xs text-slate-500">
              Practice real-world interview questions with spoken or typed answers, and receive instant AI evaluations with key concept rubrics.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Role Title */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Target Job Role</label>
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="Software Engineer - General">Software Engineer (General)</option>
                <option value="Frontend Developer">Frontend Developer (React / Web)</option>
                <option value="Backend / Systems Engineer">Backend & Systems Engineer</option>
                <option value="Database Architect">Database Architect / SQL Developer</option>
                <option value="HR Behavioral Interview">HR & Behavioral Interviewer</option>
              </select>
            </div>

            {/* Domain Category */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Question Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="all">All Categories (Technical, HR, Aptitude)</option>
                <option value="technical">Technical Questions</option>
                <option value="hr">HR & Behavioral</option>
                <option value="aptitude">Aptitude & Reasoning</option>
              </select>
            </div>

            {/* Question Count */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Interview Duration</label>
              <div className="grid grid-cols-3 gap-2">
                {[3, 5, 7].map((cnt) => (
                  <button
                    key={cnt}
                    onClick={() => setQuestionCount(cnt)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      questionCount === cnt
                        ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {cnt} Questions
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              onClick={handleStartSession}
              className="flex items-center space-x-2 bg-purple-600 hover:bg-purple-500 text-white font-bold px-6 py-3 rounded-xl transition-all shadow-md shadow-purple-600/30 cursor-pointer text-sm"
            >
              <span>Begin Mock Interview</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* LIVE SIMULATOR */}
      {sessionStarted && !sessionSubmitted && currentQ && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-sm">
          {/* Top Progress Bar */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center space-x-3">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2.5 py-1 rounded-full border border-purple-200">
                Question {currentIndex + 1} of {activeQuestions.length}
              </span>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                Role: {selectedRole}
              </span>
            </div>

            <button
              onClick={() => setShowKeyPoints(!showKeyPoints)}
              className="flex items-center space-x-1.5 text-xs text-indigo-600 font-bold bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-200 hover:bg-indigo-100 cursor-pointer"
            >
              {showKeyPoints ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{showKeyPoints ? 'Hide Key Hints' : 'Reveal Expected Points'}</span>
            </button>
          </div>

          {/* Interviewer Persona Box */}
          <div className="bg-slate-900 text-white p-5 rounded-2xl space-y-3 shadow-md">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-purple-500 text-white flex items-center justify-center font-bold">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-purple-300">Senior Technical Interviewer</span>
                <p className="text-sm font-semibold text-slate-100">{currentQ.question}</p>
              </div>
            </div>

            {currentQ.scenarioContext && (
              <p className="text-xs text-slate-300 italic pl-12 border-l-2 border-purple-400">
                "{currentQ.scenarioContext}"
              </p>
            )}
          </div>

          {/* Revealable Key Points Hint */}
          {showKeyPoints && (
            <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-4 space-y-2 animate-fade-in text-xs">
              <div className="flex items-center space-x-2 font-bold text-amber-900">
                <Lightbulb className="w-4 h-4 text-amber-600" />
                <span>Interviewer's Evaluation Criteria (Key Concepts)</span>
              </div>
              <ul className="list-disc pl-5 text-slate-700 space-y-1">
                {currentQ.keyPoints.map((kp, idx) => (
                  <li key={idx}>{kp}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Candidate Response Box */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center space-x-1.5">
                <User className="w-4 h-4 text-indigo-600" />
                <span>Your Answer Response</span>
              </label>

              {/* Speech-to-Text Button */}
              <button
                onClick={toggleMic}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                  isListening
                    ? 'bg-red-50 text-red-600 border-red-300 animate-pulse'
                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                }`}
              >
                {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-purple-600" />}
                <span>{isListening ? 'Recording... Stop' : 'Speak Answer'}</span>
              </button>
            </div>

            <textarea
              rows={5}
              value={userResponses[currentIndex] || ''}
              onChange={(e) => setUserResponses({ ...userResponses, [currentIndex]: e.target.value })}
              placeholder="Type your response here or click 'Speak Answer' to record voice input..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs sm:text-sm text-slate-900 leading-relaxed focus:outline-none focus:ring-2 focus:ring-purple-500 font-sans"
            />
          </div>

          {/* Action to Request Evaluation */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={handleEvaluateResponse}
              disabled={isEvaluating}
              className="flex items-center space-x-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold px-4 py-2 rounded-xl text-xs cursor-pointer shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{isEvaluating ? 'Evaluating with AI...' : 'Evaluate Answer with AI'}</span>
            </button>

            <button
              onClick={handleNextQuestion}
              className="flex items-center space-x-2 bg-slate-900 hover:bg-slate-800 text-white font-bold px-5 py-2.5 rounded-xl text-xs cursor-pointer"
            >
              <span>{currentIndex === activeQuestions.length - 1 ? 'Finish Interview' : 'Next Question'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Instant Evaluation Feedback Card */}
          {currentEval && (
            <div className="bg-purple-50/60 border border-purple-200 rounded-2xl p-5 space-y-4 animate-fade-in text-xs">
              <div className="flex items-center justify-between border-b border-purple-200/60 pb-3">
                <div className="flex items-center space-x-2 font-bold text-purple-900 text-sm">
                  <Award className="w-4 h-4 text-purple-600" />
                  <span>AI Feedback & Rating</span>
                </div>
                <span className="text-sm font-extrabold text-purple-700 bg-white px-3 py-1 rounded-full border border-purple-200">
                  {currentEval.score} / 10 Score
                </span>
              </div>

              <p className="text-slate-800 leading-relaxed font-medium">{currentEval.summary}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-1">
                  <span className="font-bold text-emerald-800 flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Key Strengths</span>
                  </span>
                  <ul className="list-disc pl-4 text-slate-600">
                    {currentEval.strengths?.map((str: string, i: number) => (
                      <li key={i}>{str}</li>
                    ))}
                  </ul>
                </div>

                <div className="bg-white p-3 rounded-xl border border-amber-200 space-y-1">
                  <span className="font-bold text-amber-800 flex items-center space-x-1">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                    <span>Areas for Improvement</span>
                  </span>
                  <ul className="list-disc pl-4 text-slate-600">
                    {currentEval.areasForImprovement?.map((area: string, i: number) => (
                      <li key={i}>{area}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-purple-200 space-y-1">
                <span className="font-bold text-slate-900 block">Exemplar Ideal Answer:</span>
                <p className="text-slate-700 leading-relaxed">{currentEval.idealAnswerSummary}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FINAL MOCK INTERVIEW PERFORMANCE REPORT */}
      {sessionSubmitted && finalResult && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-8 shadow-sm">
          <div className="text-center space-y-3 pb-6 border-b border-slate-100">
            <div className="w-16 h-16 bg-gradient-to-tr from-purple-600 to-indigo-600 rounded-2xl flex items-center justify-center text-white mx-auto shadow-lg shadow-purple-500/20">
              <Award className="w-8 h-8 text-amber-300" />
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-serif">
              Mock Interview Completed
            </h2>

            <div className="flex items-center justify-center space-x-2">
              <span className="text-3xl font-black text-purple-700">
                {finalResult.overallScore} / 10 Overall Rating
              </span>
            </div>

            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Role: {finalResult.roleTitle} • {finalResult.totalQuestions} Questions Evaluated
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="text-base font-bold text-slate-900">Question Evaluation Breakdown</h3>

            <div className="space-y-4">
              {finalResult.evaluations.map((ev, idx) => (
                <div key={idx} className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <span className="font-bold text-slate-900">Q{idx + 1}: {ev.question}</span>
                    <span className="font-extrabold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full">
                      Score: {ev.score}/10
                    </span>
                  </div>

                  <p className="text-slate-700 italic">"Candidate Response: {ev.userResponse}"</p>

                  <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                    <span className="font-bold text-slate-900 block">Exemplar Answer:</span>
                    <p className="text-slate-700">{ev.idealAnswerSummary}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              onClick={() => {
                setSessionStarted(false);
                setSessionSubmitted(false);
              }}
              className="flex items-center space-x-2 bg-slate-900 text-white font-bold px-5 py-2.5 rounded-xl text-xs cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Start New Mock Interview</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
