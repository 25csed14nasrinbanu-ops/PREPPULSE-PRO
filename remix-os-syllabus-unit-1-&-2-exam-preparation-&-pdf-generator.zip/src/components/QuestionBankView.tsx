import React, { useState } from 'react';
import { mcqQuestions } from '../data/mcqQuestions';
import { interviewQuestions } from '../data/interviewQuestions';
import { Search, Filter, BookOpen, Layers, Bookmark, Check, ChevronDown, ChevronUp, Sparkles, Code2 } from 'lucide-react';
import { toggleBookmarkQuestion } from '../utils/storage';

export function QuestionBankView() {
  const [viewMode, setViewMode] = useState<'list' | 'flashcards'>('list');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTopic, setSelectedTopic] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');

  // Flashcard State
  const [flashcardIndex, setFlashcardIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [expandedCardId, setExpandedCardId] = useState<string | null>(null);

  // Combine datasets
  const allBankQuestions = [
    ...mcqQuestions.map(q => ({ ...q, type: 'mcq' as const })),
    ...interviewQuestions.map(q => ({ ...q, type: 'subjective' as const }))
  ];

  const availableTopics = Array.from(new Set(allBankQuestions.map(q => q.topic)));

  // Filtered dataset
  const filteredQuestions = allBankQuestions.filter(q => {
    const matchesCategory = selectedCategory === 'all' || q.category === selectedCategory;
    const matchesTopic = selectedTopic === 'all' || q.topic === selectedTopic;
    const matchesDifficulty = selectedDifficulty === 'all' || q.difficulty === selectedDifficulty;
    const matchesSearch = searchQuery.trim() === '' ||
      q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.topic.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesTopic && matchesDifficulty && matchesSearch;
  });

  const currentFlashcard = filteredQuestions[flashcardIndex];

  return (
    <div className="space-y-6 font-sans animate-fade-in max-w-5xl mx-auto">
      {/* Header & Controls Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 font-serif tracking-tight">Question Bank & Flashcards</h2>
            <p className="text-xs text-slate-500">Explore, search, and memorize key interview questions across CS fundamentals, system design, HR, and aptitude.</p>
          </div>

          {/* Toggle View Mode */}
          <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'list' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              List View
            </button>
            <button
              onClick={() => {
                setViewMode('flashcards');
                setFlashcardIndex(0);
                setIsFlipped(false);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'flashcards' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Flashcards Mode
            </button>
          </div>
        </div>

        {/* Filters and Search Input */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search questions, keywords, topics..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Categories</option>
            <option value="technical">Technical</option>
            <option value="hr">HR & Behavioral</option>
            <option value="aptitude">Aptitude</option>
          </select>

          {/* Difficulty Filter */}
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Difficulties</option>
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </div>
      </div>

      {/* MODE 1: INTERACTIVE FLASHCARD MODE */}
      {viewMode === 'flashcards' && (
        <div className="space-y-6">
          {filteredQuestions.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 text-slate-500">
              No questions match the selected filters.
            </div>
          ) : currentFlashcard ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                <span>Card {flashcardIndex + 1} of {filteredQuestions.length}</span>
                <span className="uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700">
                  {currentFlashcard.topic} • {currentFlashcard.difficulty}
                </span>
              </div>

              {/* Flashcard Card with Flip Effect */}
              <div
                onClick={() => setIsFlipped(!isFlipped)}
                className="bg-white rounded-2xl border-2 border-indigo-200/80 p-8 min-h-[300px] flex flex-col justify-between shadow-md hover:border-indigo-400 transition-all cursor-pointer text-center relative select-none"
              >
                {!isFlipped ? (
                  // Front Side
                  <div className="my-auto space-y-4">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
                      Click Card To Flip & Reveal Answer
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif leading-relaxed">
                      {currentFlashcard.question}
                    </h3>
                  </div>
                ) : (
                  // Back Side
                  <div className="my-auto space-y-4 text-left animate-fade-in">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
                      Detailed Answer / Solution
                    </span>

                    {'explanation' in currentFlashcard && (
                      <div className="space-y-2 text-xs text-slate-800">
                        <p className="font-semibold text-emerald-800">
                          Correct Answer: {currentFlashcard.options[currentFlashcard.correctAnswerIndex]}
                        </p>
                        <p className="text-slate-600 leading-relaxed">{currentFlashcard.explanation}</p>
                      </div>
                    )}

                    {'sampleAnswer' in currentFlashcard && (
                      <div className="space-y-2 text-xs text-slate-800">
                        <p className="text-slate-700 leading-relaxed font-medium">{currentFlashcard.sampleAnswer}</p>
                        {'keyPoints' in currentFlashcard && (
                          <div className="pt-2 border-t border-slate-100">
                            <span className="font-bold text-slate-900 block mb-1">Key Points:</span>
                            <ul className="list-disc pl-4 text-slate-600 space-y-0.5">
                              {currentFlashcard.keyPoints.map((kp, i) => (
                                <li key={i}>{kp}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                <div className="pt-4 border-t border-slate-100 text-[11px] text-slate-400 font-medium">
                  {isFlipped ? 'Click card to show question' : 'Click card to reveal answer'}
                </div>
              </div>

              {/* Flashcard Navigation controls */}
              <div className="flex items-center justify-between">
                <button
                  onClick={() => {
                    setFlashcardIndex(prev => Math.max(0, prev - 1));
                    setIsFlipped(false);
                  }}
                  disabled={flashcardIndex === 0}
                  className="bg-white border border-slate-200 text-slate-800 disabled:opacity-40 font-bold px-4 py-2 rounded-xl text-xs cursor-pointer"
                >
                  Previous Card
                </button>

                <button
                  onClick={() => {
                    setFlashcardIndex(prev => Math.min(filteredQuestions.length - 1, prev + 1));
                    setIsFlipped(false);
                  }}
                  disabled={flashcardIndex === filteredQuestions.length - 1}
                  className="bg-indigo-600 text-white font-bold px-5 py-2 rounded-xl text-xs cursor-pointer hover:bg-indigo-500"
                >
                  Next Card
                </button>
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* MODE 2: LIST BROWSE VIEW */}
      {viewMode === 'list' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>Showing {filteredQuestions.length} Questions</span>
          </div>

          <div className="space-y-3">
            {filteredQuestions.map((q) => {
              const isExpanded = expandedCardId === q.id;

              return (
                <div
                  key={q.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-2xs hover:border-slate-300 transition-all"
                >
                  <div
                    onClick={() => setExpandedCardId(isExpanded ? null : q.id)}
                    className="flex items-start justify-between gap-4 cursor-pointer"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full">
                          {q.topic}
                        </span>
                        <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">
                          {q.difficulty}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-slate-400">
                          {q.type === 'mcq' ? 'MCQ' : 'Subjective'}
                        </span>
                      </div>
                      <h3 className="text-sm font-bold text-slate-900 leading-snug">{q.question}</h3>
                    </div>

                    <button className="text-slate-400 hover:text-slate-600 p-1">
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </button>
                  </div>

                  {/* Expandable Answer Content */}
                  {isExpanded && (
                    <div className="pt-3 border-t border-slate-100 space-y-3 text-xs animate-fade-in">
                      {'explanation' in q && (
                        <div className="space-y-2">
                          <p className="font-bold text-emerald-700">
                            Correct Answer: {q.options[q.correctAnswerIndex]}
                          </p>
                          <p className="text-slate-600 leading-relaxed">{q.explanation}</p>
                        </div>
                      )}

                      {'sampleAnswer' in q && (
                        <div className="space-y-2">
                          <span className="font-bold text-slate-900 block">Sample Ideal Answer:</span>
                          <p className="text-slate-700 leading-relaxed">{q.sampleAnswer}</p>

                          {'keyPoints' in q && (
                            <div className="pt-2">
                              <span className="font-bold text-slate-900 block mb-1">Key Evaluation Points:</span>
                              <ul className="list-disc pl-4 text-slate-600 space-y-0.5">
                                {q.keyPoints.map((kp, i) => (
                                  <li key={i}>{kp}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
