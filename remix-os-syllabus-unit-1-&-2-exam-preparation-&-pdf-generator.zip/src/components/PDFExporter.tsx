import React, { useState, useRef } from 'react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { Download, Printer, X, FileText, CheckCircle2, Sparkles, Loader2 } from 'lucide-react';
import { loadUserProgress } from '../utils/storage';
import { cheatSheets } from '../data/cheatSheets';

interface PDFExporterProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PDFExporter({ isOpen, onClose }: PDFExporterProps) {
  const [exportType, setExportType] = useState<'progress' | 'cheatsheet'>('progress');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const progress = loadUserProgress();
  const accuracyRate = progress.totalQuestionsAnswered > 0
    ? Math.round((progress.totalCorrectAnswers / progress.totalQuestionsAnswered) * 100)
    : 0;

  const handleDownloadPDF = async () => {
    if (!printRef.current) return;
    setIsGenerating(true);

    try {
      const element = printRef.current;
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`PrepPulse_${exportType === 'progress' ? 'Performance_Report' : 'Study_Guide'}.pdf`);
    } catch (err) {
      console.error('Error generating PDF:', err);
      alert('Could not generate PDF. Printing standard fallback view...');
      window.print();
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-6 shadow-2xl border border-slate-200 font-sans max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-slate-900 font-serif">Export PDF Report & Study Guide</h3>
              <p className="text-xs text-slate-500">Download formatted PDF report for offline review or printing.</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg cursor-pointer font-bold"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Export Type Switcher */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setExportType('progress')}
            className={`p-3.5 rounded-xl border text-left text-xs font-bold transition-all cursor-pointer ${
              exportType === 'progress'
                ? 'bg-indigo-50 border-indigo-400 text-indigo-950 shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <span className="block text-sm font-extrabold">1. User Performance Report</span>
            <span className="text-[11px] font-normal text-slate-500">Practice stats, quiz accuracy, and completed mock interviews</span>
          </button>

          <button
            onClick={() => setExportType('cheatsheet')}
            className={`p-3.5 rounded-xl border text-left text-xs font-bold transition-all cursor-pointer ${
              exportType === 'cheatsheet'
                ? 'bg-indigo-50 border-indigo-400 text-indigo-950 shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <span className="block text-sm font-extrabold">2. Interview Study Cheat Sheet</span>
            <span className="text-[11px] font-normal text-slate-500">Big-O matrix, SQL syntax, System Design, and STAR method</span>
          </button>
        </div>

        {/* Printable Canvas Element */}
        <div className="border border-slate-200 rounded-xl p-6 bg-slate-50 max-h-80 overflow-y-auto">
          <div ref={printRef} className="bg-white p-6 rounded-xl border border-slate-200 space-y-6 text-slate-900 text-xs font-sans">
            {/* PDF Document Header */}
            <div className="border-b-2 border-slate-900 pb-3 flex justify-between items-end">
              <div>
                <h1 className="text-xl font-black text-slate-900 uppercase font-serif tracking-tight">PrepPulse Interview Preparation Suite</h1>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                  {exportType === 'progress' ? 'Personal Progress & Accuracy Report' : 'Technical & Behavioral Study Guide'}
                </p>
              </div>
              <span className="text-[10px] font-semibold text-slate-400">{new Date().toLocaleDateString()}</span>
            </div>

            {exportType === 'progress' ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block">Quizzes Completed</span>
                    <span className="text-lg font-black text-indigo-600">{progress.quizzesCompleted}</span>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block">Mock Interviews</span>
                    <span className="text-lg font-black text-purple-600">{progress.mockInterviewsCompleted}</span>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block">Quiz Accuracy</span>
                    <span className="text-lg font-black text-emerald-600">{accuracyRate}%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="font-bold text-slate-900 text-xs block uppercase border-b pb-1">Recent Practice History</span>
                  {progress.quizHistory.slice(0, 4).map((q) => (
                    <div key={q.id} className="flex justify-between items-center py-1.5 border-b border-slate-100 text-[11px]">
                      <span>Quiz: {q.topic} ({q.difficulty})</span>
                      <span className="font-bold">{q.score}/{q.totalQuestions} ({q.percentage}%)</span>
                    </div>
                  ))}
                  {progress.mockHistory.slice(0, 4).map((m) => (
                    <div key={m.id} className="flex justify-between items-center py-1.5 border-b border-slate-100 text-[11px]">
                      <span>Mock Interview: {m.roleTitle}</span>
                      <span className="font-bold text-purple-700">{m.overallScore}/10 Score</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                {cheatSheets.map((cs) => (
                  <div key={cs.id} className="space-y-1 pb-3 border-b border-slate-100">
                    <h4 className="font-bold text-slate-900">{cs.title}</h4>
                    <p className="text-[11px] text-slate-600">{cs.summary}</p>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-2 text-[9px] text-slate-400 text-center uppercase tracking-widest border-t border-slate-100">
              Generated via PrepPulse Platform • www.preppulse.app
            </div>
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="flex items-center justify-between border-t border-slate-100 pt-4">
          <button
            onClick={() => window.print()}
            className="flex items-center space-x-1.5 text-slate-600 hover:text-slate-900 text-xs font-bold cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print View</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            disabled={isGenerating}
            className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs cursor-pointer shadow-md shadow-indigo-600/30"
          >
            {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            <span>{isGenerating ? 'Generating PDF...' : 'Download Vector PDF'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
