import React, { useState } from 'react';
import { UserProgress, ActiveTab } from '../types';
import {
  CheckCircle2,
  Mic,
  Award,
  Zap,
  TrendingUp,
  Brain,
  Code2,
  Users,
  Calculator,
  ArrowRight,
  Clock,
  Sparkles,
  RotateCcw,
  BookOpen,
  ChevronRight,
  Target
} from 'lucide-react';
import { resetUserProgress } from '../utils/storage';

interface DashboardViewProps {
  progress: UserProgress;
  onSelectTab: (tab: ActiveTab) => void;
  onRefreshProgress: () => void;
}

export function DashboardView({ progress, onSelectTab, onRefreshProgress }: DashboardViewProps) {
  const [selectedHistoryItem, setSelectedHistoryItem] = useState<any | null>(null);

  const accuracyRate = progress.totalQuestionsAnswered > 0
    ? Math.round((progress.totalCorrectAnswers / progress.totalQuestionsAnswered) * 100)
    : 0;

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset your practice stats and history? This cannot be undone.')) {
      resetUserProgress();
      onRefreshProgress();
    }
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-8 shadow-xl border border-slate-800">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI-Enhanced Interview Preparation Platform</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white font-serif">
            Master Technical & Behavioral Interviews
          </h1>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Practice topic-wise MCQs, simulate realistic mock interviews with instant feedback, and track your performance across Computer Science fundamentals, System Design, HR, and Aptitude.
          </p>

          <div className="pt-3 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSelectTab('mcq')}
              className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl transition-all shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>Start Practice MCQ Quiz</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            <button
              onClick={() => onSelectTab('mock')}
              className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl border border-white/20 transition-all cursor-pointer backdrop-blur-sm"
            >
              <Mic className="w-4 h-4 text-indigo-300" />
              <span>Launch Mock Interview</span>
            </button>
          </div>
        </div>

        {/* Ambient background blur */}
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Quizzes Taken</p>
            <h3 className="text-2xl font-bold text-slate-900 mt-0.5">{progress.quizzesCompleted}</h3>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <Mic className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Mock Interviews</p>
            <h3 className="text-2xl font-bold text-slate-900 mt-0.5">{progress.mockInterviewsCompleted}</h3>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Quiz Accuracy</p>
            <h3 className="text-2xl font-bold text-slate-900 mt-0.5">{accuracyRate}%</h3>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Questions Solved</p>
            <h3 className="text-2xl font-bold text-slate-900 mt-0.5">{progress.totalQuestionsAnswered}</h3>
          </div>
        </div>
      </div>

      {/* Category Selection Cards */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
            <Target className="w-5 h-5 text-indigo-600" />
            <span>Practice Categories</span>
          </h2>
          <span className="text-xs font-medium text-slate-500">Choose a domain to start practicing</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Technical Questions */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Code2 className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Technical & CS Fundamentals</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Operating Systems, Data Structures & Algorithms, System Design, SQL, and Computer Networks.
              </p>
            </div>
            <div className="pt-2 flex items-center justify-between border-t border-slate-100">
              <span className="text-[11px] font-semibold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
                40+ MCQs & 20+ Subjective Qs
              </span>
              <button
                onClick={() => onSelectTab('mcq')}
                className="text-xs font-bold text-slate-900 hover:text-indigo-600 flex items-center space-x-1 cursor-pointer"
              >
                <span>Practice</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 2: HR & Behavioral Questions */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">HR & Behavioral Interview</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                STAR method framing, conflict resolution, career goals, leadership, and workplace scenarios.
              </p>
            </div>
            <div className="pt-2 flex items-center justify-between border-t border-slate-100">
              <span className="text-[11px] font-semibold text-purple-600 bg-purple-50 px-2.5 py-1 rounded-full">
                STAR Method Simulation
              </span>
              <button
                onClick={() => onSelectTab('mock')}
                className="text-xs font-bold text-slate-900 hover:text-purple-600 flex items-center space-x-1 cursor-pointer"
              >
                <span>Mock Interview</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 3: Quantitative Aptitude */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <Calculator className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Quantitative & Reasoning</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Speed, Distance, Percentages, Work & Time, Logical Deduction, Number Series, and Data Interpretation.
              </p>
            </div>
            <div className="pt-2 flex items-center justify-between border-t border-slate-100">
              <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
                Timed Practice Mode
              </span>
              <button
                onClick={() => onSelectTab('mcq')}
                className="text-xs font-bold text-slate-900 hover:text-emerald-600 flex items-center space-x-1 cursor-pointer"
              >
                <span>Solve Math</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity Log */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-xs">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
            <Clock className="w-5 h-5 text-indigo-600" />
            <span>Recent Practice History</span>
          </h2>

          {progress.quizHistory.length > 0 || progress.mockHistory.length > 0 ? (
            <button
              onClick={handleReset}
              className="text-xs text-slate-400 hover:text-red-600 flex items-center space-x-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Data</span>
            </button>
          ) : null}
        </div>

        {progress.quizHistory.length === 0 && progress.mockHistory.length === 0 ? (
          <div className="text-center py-8 border-2 border-dashed border-slate-200 rounded-xl space-y-3">
            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
              <BookOpen className="w-6 h-6" />
            </div>
            <p className="text-sm font-medium text-slate-600">No practice sessions completed yet.</p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Start an MCQ practice quiz or a Mock Interview to track your score, accuracy, and areas for improvement!
            </p>
            <button
              onClick={() => onSelectTab('mcq')}
              className="inline-flex items-center space-x-2 bg-indigo-600 text-white text-xs font-bold px-4 py-2 rounded-lg hover:bg-indigo-700 cursor-pointer"
            >
              <span>Take Your First Quiz</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold">
                  <th className="pb-3">Type</th>
                  <th className="pb-3">Topic / Role</th>
                  <th className="pb-3">Difficulty</th>
                  <th className="pb-3">Score / Rating</th>
                  <th className="pb-3">Date</th>
                  <th className="pb-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {progress.quizHistory.slice(0, 5).map((q) => (
                  <tr key={q.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 font-semibold text-indigo-600 flex items-center space-x-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>MCQ Quiz</span>
                    </td>
                    <td className="py-3 font-medium text-slate-900">{q.topic}</td>
                    <td className="py-3 uppercase text-[10px] font-bold tracking-wider text-slate-500">
                      {q.difficulty}
                    </td>
                    <td className="py-3 font-bold text-slate-900">
                      <span className={`px-2 py-0.5 rounded-full ${q.percentage >= 70 ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                        {q.score}/{q.totalQuestions} ({q.percentage}%)
                      </span>
                    </td>
                    <td className="py-3 text-slate-500">{q.date}</td>
                    <td className="py-3 text-right">
                      <button
                        onClick={() => setSelectedHistoryItem({ type: 'quiz', data: q })}
                        className="text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                ))}

                {progress.mockHistory.slice(0, 5).map((m) => (
                  <tr key={m.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 font-semibold text-purple-600 flex items-center space-x-1.5">
                      <Mic className="w-3.5 h-3.5" />
                      <span>Mock Interview</span>
                    </td>
                    <td className="py-3 font-medium text-slate-900">{m.roleTitle}</td>
                    <td className="py-3 uppercase text-[10px] font-bold tracking-wider text-slate-500">
                      {m.difficulty}
                    </td>
                    <td className="py-3 font-bold text-slate-900">
                      <span className={`px-2 py-0.5 rounded-full ${m.overallScore >= 7 ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                        {m.overallScore} / 10 Score
                      </span>
                    </td>
                    <td className="py-3 text-slate-500">{m.date}</td>
                    <td className="py-3 text-right">
                      <button
                        onClick={() => setSelectedHistoryItem({ type: 'mock', data: m })}
                        className="text-purple-600 hover:text-purple-800 font-bold cursor-pointer"
                      >
                        Review
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* History Details Modal */}
      {selectedHistoryItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-lg text-slate-900">
                {selectedHistoryItem.type === 'quiz' ? 'Quiz Performance Summary' : 'Mock Interview Evaluation'}
              </h3>
              <button
                onClick={() => setSelectedHistoryItem(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {selectedHistoryItem.type === 'quiz' ? (
              <div className="space-y-3 text-xs text-slate-700">
                <p><strong>Topic:</strong> {selectedHistoryItem.data.topic}</p>
                <p><strong>Score:</strong> {selectedHistoryItem.data.score} / {selectedHistoryItem.data.totalQuestions} ({selectedHistoryItem.data.percentage}%)</p>
                <p><strong>Time Taken:</strong> {Math.round(selectedHistoryItem.data.timeSpentSeconds)} seconds</p>
                <p><strong>Date:</strong> {selectedHistoryItem.data.date}</p>
              </div>
            ) : (
              <div className="space-y-3 text-xs text-slate-700 max-h-80 overflow-y-auto">
                <p><strong>Role:</strong> {selectedHistoryItem.data.roleTitle}</p>
                <p><strong>Overall Score:</strong> {selectedHistoryItem.data.overallScore} / 10</p>
                <div className="pt-2 space-y-2">
                  <p className="font-bold text-slate-900">Questions Answered:</p>
                  {selectedHistoryItem.data.evaluations.map((ev: any, idx: number) => (
                    <div key={idx} className="bg-slate-50 p-3 rounded-lg space-y-1">
                      <p className="font-semibold text-slate-800">Q{idx + 1}: {ev.question}</p>
                      <p className="text-slate-600 italic">"Response: {ev.userResponse}"</p>
                      <p className="text-indigo-600 font-bold">Feedback: {ev.idealAnswerSummary}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setSelectedHistoryItem(null)}
                className="bg-slate-900 text-white font-bold px-4 py-2 rounded-lg text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
