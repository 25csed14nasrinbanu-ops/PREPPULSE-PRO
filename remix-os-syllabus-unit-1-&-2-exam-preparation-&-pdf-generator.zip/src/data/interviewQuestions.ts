import { InterviewQuestion } from '../types';

export const interviewQuestions: InterviewQuestion[] = [
  // TECHNICAL - SYSTEM DESIGN
  {
    id: 'int-sys-1',
    category: 'technical',
    topic: 'System Design',
    difficulty: 'hard',
    question: 'How would you design a scalable URL Shortener service like TinyURL or bit.ly?',
    scenarioContext: 'You are interviewing for a Senior Systems Engineer role. The interviewer asks you to scale a service to support 100 million daily active links generated.',
    answerHint: 'Discuss functional & non-functional requirements, API endpoints, unique ID generation (Base62 vs Hash + collision resolution), database schema, caching (Redis), and database sharding.',
    keyPoints: [
      'Functional vs Non-functional requirements (low latency, high availability, custom short links)',
      'Base62 encoding (0-9, a-z, A-Z) of auto-incrementing IDs or MD5 hash truncation',
      'Database choice (NoSQL like Cassandra/DynamoDB for high write throughput)',
      'Caching layer with Redis (LRU policy for top 20% viral URLs)',
      'Load Balancers & Rate Limiting to prevent malicious spam'
    ],
    sampleAnswer: 'To design a scalable URL Shortener, I start by establishing requirements: 100M new URLs/day with 10:1 read-to-write ratio. For encoding, Base62 is optimal (62^7 = 3.5 Trillion unique 7-character strings). A centralized KGS (Key Generation Service) pre-generates unique 7-character strings to prevent runtime collisions across server nodes. Database-wise, a NoSQL key-value store like Cassandra or DynamoDB easily scales horizontally with URL string as primary key. For fast reads, a Redis cache stores the most frequently accessed URLs using an LRU eviction strategy.',
    followUpQuestions: [
      'How do you handle custom short alias requests from users?',
      'How would you collect analytics like click count and geographic traffic without slowing down redirects?'
    ]
  },

  // TECHNICAL - OPERATING SYSTEMS & CONCURRENCY
  {
    id: 'int-os-1',
    category: 'technical',
    topic: 'Operating Systems',
    difficulty: 'medium',
    question: 'Explain the difference between a Process and a Thread. When would you choose multi-threading over multi-processing?',
    scenarioContext: 'Core CS fundamentals interview question testing process memory space, context switching overhead, and IPC.',
    answerHint: 'Compare memory space, context switching cost, isolation, communication overhead, and crash impact.',
    keyPoints: [
      'A Process is an independent executing program with its own address space (Code, Data, Heap, Stack)',
      'A Thread is a lightweight execution unit inside a process sharing the same address space and heap',
      'Context switching between threads is faster than between processes because page tables don\'t change',
      'Inter-process communication (IPC) requires OS primitives (pipes, sockets, shared memory), whereas threads communicate directly via shared memory',
      'A crash in one process does not kill other processes, whereas an unhandled fault in a thread can crash the entire process'
    ],
    sampleAnswer: 'A Process is an isolated program instance with its own virtual address space, heap, and open file descriptors, ensuring high security and fault isolation. A Thread is an execution context inside a process that shares memory and heap with sibling threads. Multi-threading is preferred for memory-heavy or CPU-intensive tasks requiring frequent data sharing (like a web server handling concurrent HTTP requests), because thread context switches incur lower CPU overhead. Multi-processing is chosen when fault isolation is paramount (e.g., Chrome browser rendering separate tabs independently) or to bypass Single Thread Locks in interpreted languages like Python\'s GIL.',
    codeExample: `// Node.js Worker Threads vs Child Processes concept
// Threads share memory via SharedArrayBuffer
// Processes communicate via IPC messaging (process.send)`
  },

  // TECHNICAL - DATA STRUCTURES & CODING
  {
    id: 'int-dsa-1',
    category: 'technical',
    topic: 'Data Structures & Algorithms',
    difficulty: 'medium',
    question: 'How do you detect a cycle in a Linked List, and how do you find the starting node of the cycle?',
    scenarioContext: 'Coding Interview question testing pointers, two-pointer techniques, and Floyd\'s Cycle Detection algorithm.',
    answerHint: 'Explain Floyd\'s Tortoise and Hare algorithm (slow and fast pointers) and the mathematical proof for finding the entry node.',
    keyPoints: [
      'Initialize slow pointer moving 1 step and fast pointer moving 2 steps',
      'If fast or fast.next becomes null, there is no cycle',
      'If slow and fast meet, a cycle exists',
      'To find cycle entry: reset slow pointer to head, keep fast pointer at meeting point, move both 1 step at a time until they meet again'
    ],
    sampleAnswer: 'We use Floyd\'s Cycle-Finding Algorithm (Tortoise and Hare). We maintain two pointers: `slow` moving one node at a time and `fast` moving two nodes at a time. If `fast` or `fast.next` reaches null, the list has no cycle. If `slow === fast`, a cycle exists. To find the starting node of the cycle, we reset `slow` to the `head` while keeping `fast` at the intersection point. We then move both pointers one step at a time; the node where they meet again is the exact start of the cycle. This runs in O(n) time and O(1) space.',
    codeExample: `function detectCycle(head) {
  let slow = head, fast = head;
  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
    if (slow === fast) {
      slow = head;
      while (slow !== fast) {
        slow = slow.next;
        fast = fast.next;
      }
      return slow; // Entry node
    }
  }
  return null;
}`
  },

  // TECHNICAL - DATABASE & SQL
  {
    id: 'int-db-1',
    category: 'technical',
    topic: 'Database Management (SQL)',
    difficulty: 'medium',
    question: 'What is a Database Index? How does a B+ Tree index work, and what are the trade-offs of adding too many indexes?',
    scenarioContext: 'Backend / Database Architect interview question on database performance tuning and execution plans.',
    answerHint: 'Discuss B+ Tree node structure, search efficiency O(log N), sequential leaf traversal, and INSERT/UPDATE write overhead.',
    keyPoints: [
      'A Database Index is a data structure (typically B+ Tree) that optimizes query search speed',
      'B+ Trees store data pointers only at leaf nodes, connected sequentially for fast range scans',
      'Index lookup turns full table scans O(N) into B+ Tree traversals O(log N)',
      'Trade-offs: Extra disk memory storage, slower INSERT/UPDATE/DELETE queries because index trees must be re-balanced'
    ],
    sampleAnswer: 'A database index is an auxiliary data structure that enables fast data retrieval without scanning every row in a table. Most SQL engines use B+ Trees, where internal nodes store key search ranges and leaf nodes contain actual data pointers (or clustered row data) linked as a doubly-linked list for efficient range scans. While indexes dramatically speed up SELECT queries with WHERE and JOIN conditions, adding too many indexes degrades write performance (INSERT/UPDATE/DELETE queries must rebalance index trees) and increases storage overhead.',
    followUpQuestions: [
      'What is the difference between a Clustered Index and a Non-Clustered Index?',
      'When would a database query optimizer decide to ignore an existing index?'
    ]
  },

  // HR & BEHAVIORAL - STAR METHOD
  {
    id: 'int-hr-1',
    category: 'hr',
    topic: 'Behavioral & STAR Method',
    difficulty: 'medium',
    question: 'Tell me about a time you faced a tight project deadline with ambiguous requirements. How did you handle it?',
    scenarioContext: 'Behavioral HR interview question designed to evaluate adaptability, communication, prioritization, and execution under pressure.',
    answerHint: 'Structure response strictly using STAR: Situation, Task, Action, Result. Highlight proactive stakeholder alignment and MVP scoping.',
    keyPoints: [
      'Situation: Clear project context with tight deadline (e.g. 2 weeks) and vague client goals',
      'Task: Need to deliver a functional core product on schedule without risking quality',
      'Action: Broke down requirements, conducted quick alignment workshop with product manager, prioritized an MVP backlog, communicated daily status',
      'Result: Successfully launched core MVP on time with 0 critical bugs, praised for proactive leadership'
    ],
    sampleAnswer: 'Situation: During my previous team project, we had 2 weeks to launch an user analytics feature, but the client requirements were vague. Task: I was responsible for delivering a reliable solution on time. Action: I proactively organized a 30-minute scope alignment meeting with the product owner, defined 3 non-negotiable core metrics for the MVP, and deferred optional features to Sprint 2. I created quick wireframes and updated the team daily. Result: We deployed the core dashboard 1 day ahead of deadline with 100% test coverage and received positive feedback from leadership for proactive clarity.',
    followUpQuestions: [
      'What would you do if a team member failed to complete their task on deadline day?',
      'How do you handle scope creep during an ongoing sprint?'
    ]
  },

  // HR & BEHAVIORAL - CONFLICT & LEADERSHIP
  {
    id: 'int-hr-2',
    category: 'hr',
    topic: 'Conflict & Leadership',
    difficulty: 'medium',
    question: 'Describe a situation where you had a strong technical disagreement with a teammate. How did you resolve it?',
    scenarioContext: 'Assessing collaboration, emotional intelligence, open-mindedness, and commitment to project goals.',
    answerHint: 'Focus on objective benchmark data, active listening, staying calm, and committing to the best outcome for the product.',
    keyPoints: [
      'Acknowledge that healthy technical disagreements lead to better engineering decisions',
      'Active listening: understand the teammate\'s perspective and constraints',
      'Data-driven approach: run quick benchmarks, proof-of-concept (POC), or compare pros/cons matrix',
      'Disagree and commit: agree on a path forward aligned with team goals'
    ],
    sampleAnswer: 'When selecting a state management library for our frontend, my teammate preferred Redux while I advocated for Zustand due to lower boilerplate. Instead of arguing opinion, I proposed building a 1-hour Proof of Concept with both libraries and benchmarking bundle size and developer experience. The benchmarks showed Zustand reduced bundle size by 15KB with simpler TypeScript setup. After reviewing the POC together, my teammate agreed, and we successfully adopted Zustand, completing the project ahead of schedule.',
    followUpQuestions: [
      'How do you receive constructive criticism during code reviews?'
    ]
  },

  // QUANTITATIVE APTITUDE & REASONING
  {
    id: 'int-apt-1',
    category: 'aptitude',
    topic: 'Quantitative Reasoning',
    difficulty: 'easy',
    question: 'How do you solve probability and combinations problems like "Finding the probability of drawing 2 Aces in sequence from a standard 52-card deck without replacement"?',
    scenarioContext: 'Screening round math problem evaluating step-by-step probability logic.',
    answerHint: 'Calculate P(First Ace) × P(Second Ace given First is Ace).',
    keyPoints: [
      'Total cards = 52, Total Aces = 4',
      'Probability of 1st Ace = 4/52 = 1/13',
      'Cards remaining = 51, Aces remaining = 3',
      'Probability of 2nd Ace = 3/51 = 1/17',
      'Combined Probability = (1/13) × (1/17) = 1/221 ≈ 0.45%'
    ],
    sampleAnswer: 'To find the probability without replacement, we multiply conditional probabilities: First card is an Ace with P(A1) = 4/52 = 1/13. With 1 Ace removed, there are 3 Aces left in 51 remaining cards, so P(A2|A1) = 3/51 = 1/17. Combined probability P = (1/13) × (1/17) = 1/221 (approx 0.45%).'
  }
];
