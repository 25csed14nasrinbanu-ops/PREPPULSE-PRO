import { CheatSheetItem } from '../types';

export const cheatSheets: CheatSheetItem[] = [
  {
    id: 'cs-big-o',
    title: 'Data Structures & Big-O Complexity Matrix',
    category: 'technical',
    topic: 'Data Structures & Algorithms',
    summary: 'Essential time & space complexities for fundamental data structures, sorting algorithms, and traversal techniques.',
    sections: [
      {
        title: 'Data Structure Time Complexities',
        content: 'Common data structures and their operations performance:',
        code: `Data Structure   | Access | Search | Insertion | Deletion | Space
-----------------|--------|--------|-----------|----------|-------
Array / Vector   | O(1)   | O(n)   | O(n)      | O(n)     | O(n)
Stack            | O(n)   | O(n)   | O(1)      | O(1)     | O(n)
Queue            | O(n)   | O(n)   | O(1)      | O(1)     | O(n)
Singly Linked    | O(n)   | O(n)   | O(1)*     | O(1)*    | O(n)
Hash Table       | N/A    | O(1)   | O(1)      | O(1)     | O(n)
Binary Search    | O(log) | O(log) | O(log n)  | O(log n) | O(n)
Tree (Balanced)  | n)     | n)     |           |          |`,
        keyTakeaways: [
          'Hash Tables provide O(1) average search/insert/delete but degrade to O(n) with collisions.',
          'Arrays have O(1) random access by index but O(n) element shifts on middle insertions.',
          'Balanced BSTs (AVL, Red-Black) guarantee O(log n) operations in worst case.'
        ]
      },
      {
        title: 'Sorting Algorithms Overview',
        content: 'Comparison of popular sorting algorithms:',
        code: `Algorithm     | Best Time  | Average    | Worst Time | Space    | Stable?
--------------|------------|------------|------------|----------|--------
Quick Sort    | O(n log n) | O(n log n) | O(n²)      | O(log n) | No
Merge Sort    | O(n log n) | O(n log n) | O(n log n) | O(n)     | Yes
Heap Sort     | O(n log n) | O(n log n) | O(n log n) | O(1)     | No
Insertion Sort| O(n)       | O(n²)      | O(n²)      | O(1)     | Yes`,
        keyTakeaways: [
          'Use Merge Sort when stability is required or sorting linked lists.',
          'Quick Sort is often faster in practice due to cache locality despite O(n²) worst case.',
          'Heap Sort provides O(n log n) worst-case time with strictly O(1) auxiliary space.'
        ]
      }
    ]
  },
  {
    id: 'cs-sql',
    title: 'SQL & Database Architecture Cheat Sheet',
    category: 'technical',
    topic: 'Database Management (SQL)',
    summary: 'Core SQL queries, JOIN types, Indexing strategies, and ACID transaction rules for database interviews.',
    sections: [
      {
        title: 'Essential SQL Window Functions & Aggregations',
        content: 'Frequently asked SQL queries in technical interviews:',
        code: `-- Find 2nd highest salary using ROW_NUMBER()
WITH RankedSalaries AS (
  SELECT employee_id, salary,
         DENSE_RANK() OVER (ORDER BY salary DESC) as rank
  FROM employees
)
SELECT salary FROM RankedSalaries WHERE rank = 2;

-- GROUP BY with HAVING clause
SELECT department_id, COUNT(*) as emp_count, AVG(salary) as avg_sal
FROM employees
GROUP BY department_id
HAVING AVG(salary) > 75000;`,
        keyTakeaways: [
          'DENSE_RANK() does not skip rank numbers when duplicate values exist.',
          'HAVING filters aggregated groups, WHERE filters individual source rows.'
        ]
      },
      {
        title: 'ACID Properties Quick Summary',
        content: 'Fundamental rules guaranteeing database transaction reliability:',
        code: `A - Atomicity   : All operations in a transaction succeed, or all roll back (All-or-Nothing).
C - Consistency : Data satisfies all schema constraints & triggers before & after transaction.
I - Isolation   : Concurrent transactions execute independently without dirty reads.
D - Durability  : Committed transactions survive system power failures or crashes.`,
        keyTakeaways: [
          'Isolation levels: Read Uncommitted < Read Committed < Repeatable Read < Serializable.'
        ]
      }
    ]
  },
  {
    id: 'cs-sys-design',
    title: 'System Design Interview Framework',
    category: 'technical',
    topic: 'System Design',
    summary: 'A 5-step structured blueprint for tackling system design interview questions.',
    sections: [
      {
        title: '5-Step System Design Blueprint',
        content: 'Follow this timeline during 45-minute design interviews:',
        code: `Step 1: Clarify Requirements (5 mins)
  - Functional: What actions can users take? (e.g., upload photo, view feed)
  - Non-Functional: Scale (10M DAU), Latency (<200ms), Availability (99.99%), CAP choice.

Step 2: High-Level Architecture (10 mins)
  - Draw components: Client -> Load Balancer -> API Gateway -> Microservices -> DB & Cache.

Step 3: Database Schema & Storage (10 mins)
  - SQL vs NoSQL evaluation, Blob storage (S3) for media, Cache (Redis).

Step 4: Detailed Component Design (15 mins)
  - Key Generation, Rate Limiting, Message Queues (Kafka/RabbitMQ), Sharding.

Step 5: Bottlenecks & Failure Scenarios (5 mins)
  - Single Point of Failure (SPOF), Replication, Monitoring, Graceful Degradation.`,
        keyTakeaways: [
          'Never jump straight into drawing boxes; clarify capacity estimates and scale first.',
          'Always address caching, database replication, and load balancing.'
        ]
      }
    ]
  },
  {
    id: 'cs-star',
    title: 'HR & Behavioral Interview STAR Method Guide',
    category: 'hr',
    topic: 'Behavioral & STAR Method',
    summary: 'Mastering behavioral interview responses with actionable story structures and leadership principles.',
    sections: [
      {
        title: 'The STAR Method Formula',
        content: 'Structure every behavioral story in 2 to 3 minutes:',
        code: `S - Situation (15%): Set the scene, team size, project context, and constraints.
T - Task      (15%): Explain the specific challenge or goal you were responsible for.
A - Action    (50%): Detail YOUR individual contributions, decisions, and problem solving.
R - Result    (20%): Quantify the outcome with metrics (% speedup, $ saved, bugs reduced).`,
        keyTakeaways: [
          'Focus on "I" rather than "We" when describing the Action phase.',
          'Always end with measurable metrics and reflections on key takeaways.'
        ]
      }
    ]
  }
];
