import { MCQQuestion } from '../types';

export const mcqQuestions: MCQQuestion[] = [
  // TECHNICAL - OPERATING SYSTEMS
  {
    id: 'mcq-os-1',
    category: 'technical',
    topic: 'Operating Systems',
    difficulty: 'easy',
    question: 'What is the primary function of the operating system kernel?',
    options: [
      'Provide user interface themes and icons',
      'Manage system resources like CPU, memory, and hardware devices',
      'Compile source code into executable binary files',
      'Perform database indexing and relational queries'
    ],
    correctAnswerIndex: 1,
    explanation: 'The kernel is the core component of an operating system that acts as a bridge between applications and actual data processing done at the hardware level, managing CPU scheduling, memory allocation, and I/O devices.',
    tags: ['Kernel', 'OS Core', 'Resource Management']
  },
  {
    id: 'mcq-os-2',
    category: 'technical',
    topic: 'Operating Systems',
    difficulty: 'medium',
    question: 'Which CPU scheduling algorithm can lead to the "convoy effect"?',
    options: [
      'Shortest Job First (SJF)',
      'Round Robin (RR)',
      'First-Come, First-Served (FCFS)',
      'Priority Scheduling'
    ],
    correctAnswerIndex: 2,
    explanation: 'The convoy effect occurs in FCFS scheduling when a CPU-bound process with a long burst time gets the CPU first, forcing many short I/O-bound processes to wait behind it in the ready queue.',
    tags: ['CPU Scheduling', 'FCFS', 'Convoy Effect']
  },
  {
    id: 'mcq-os-3',
    category: 'technical',
    topic: 'Operating Systems',
    difficulty: 'hard',
    question: 'Which of the following conditions is NOT required for a deadlock to occur according to Coffman conditions?',
    options: [
      'Mutual Exclusion',
      'Hold and Wait',
      'Preemption',
      'Circular Wait'
    ],
    correctAnswerIndex: 2,
    explanation: 'The four Coffman conditions for deadlock are: 1. Mutual Exclusion, 2. Hold and Wait, 3. NO Preemption (resources cannot be forcibly taken away), and 4. Circular Wait. Preemption prevents deadlocks.',
    tags: ['Deadlocks', 'Coffman Conditions', 'Synchronization']
  },
  {
    id: 'mcq-os-4',
    category: 'technical',
    topic: 'Operating Systems',
    difficulty: 'medium',
    question: 'What happens during a context switch in a multi-tasking OS?',
    options: [
      'The CPU switches off and restarts',
      'The state (context) of the active process is saved and the state of the new process is restored',
      'All processes in memory are cleared to free up cache',
      'Virtual memory is permanently written to physical disk'
    ],
    correctAnswerIndex: 1,
    explanation: 'A context switch involves saving the current state (registers, program counter, PCB) of the running process so that it can be resumed later, and loading the saved state of another process.',
    tags: ['Context Switch', 'Process Control Block', 'Concurrency']
  },

  // TECHNICAL - DATA STRUCTURES & ALGORITHMS
  {
    id: 'mcq-dsa-1',
    category: 'technical',
    topic: 'Data Structures & Algorithms',
    difficulty: 'easy',
    question: 'What is the time complexity of searching for an element in a balanced Binary Search Tree (BST)?',
    options: ['O(1)', 'O(n)', 'O(log n)', 'O(n log n)'],
    correctAnswerIndex: 2,
    explanation: 'In a balanced BST, each comparison eliminates half of the remaining nodes, leading to a logarithmic time complexity O(log n).',
    tags: ['BST', 'Time Complexity', 'Trees']
  },
  {
    id: 'mcq-dsa-2',
    category: 'technical',
    topic: 'Data Structures & Algorithms',
    difficulty: 'medium',
    codeSnippet: `function mystery(n) {
  let count = 0;
  for (let i = 1; i < n; i *= 2) {
    count++;
  }
  return count;
}`,
    question: 'What is the time complexity of the JavaScript snippet shown above?',
    options: ['O(n)', 'O(log n)', 'O(n²)', 'O(sqrt(n))'],
    correctAnswerIndex: 1,
    explanation: 'Since the loop variable `i` doubles in each iteration (`i *= 2`), the number of iterations required to reach `n` is proportional to log2(n).',
    tags: ['Big-O', 'Code Analysis', 'Loops']
  },
  {
    id: 'mcq-dsa-3',
    category: 'technical',
    topic: 'Data Structures & Algorithms',
    difficulty: 'hard',
    question: 'Which algorithm is used to find the shortest path from a single source node to all other nodes in a weighted graph with non-negative edge weights?',
    options: [
      'Floyd-Warshall Algorithm',
      'Dijkstra\'s Algorithm',
      'Bellman-Ford Algorithm',
      'Kruskal\'s Algorithm'
    ],
    correctAnswerIndex: 1,
    explanation: 'Dijkstra\'s algorithm finds single-source shortest paths in graphs with non-negative edge weights using a greedy min-priority queue approach in O((V + E) log V) time.',
    tags: ['Graphs', 'Dijkstra', 'Shortest Path']
  },
  {
    id: 'mcq-dsa-4',
    category: 'technical',
    topic: 'Data Structures & Algorithms',
    difficulty: 'medium',
    question: 'Which data structure is fundamentally used to implement Function Call Stacks and Depth-First Search (DFS)?',
    options: ['Queue', 'Stack', 'Heap', 'Linked List'],
    correctAnswerIndex: 1,
    explanation: 'Stacks operate on a Last-In, First-Out (LIFO) basis, making them ideal for tracking nested function calls, recursive backtraces, and DFS traversals.',
    tags: ['Stack', 'LIFO', 'DFS']
  },

  // TECHNICAL - DATABASE MANAGEMENT (SQL)
  {
    id: 'mcq-db-1',
    category: 'technical',
    topic: 'Database Management (SQL)',
    difficulty: 'easy',
    question: 'Which SQL clause is used to filter group records after an aggregation (e.g., GROUP BY)?',
    options: ['WHERE', 'HAVING', 'ORDER BY', 'FILTER'],
    correctAnswerIndex: 1,
    explanation: 'The HAVING clause is evaluated after GROUP BY to filter grouped result sets, whereas WHERE filters individual rows before grouping takes place.',
    tags: ['SQL', 'HAVING', 'GROUP BY']
  },
  {
    id: 'mcq-db-2',
    category: 'technical',
    topic: 'Database Management (SQL)',
    difficulty: 'medium',
    question: 'What does the "I" in ACID properties of a database transaction stand for?',
    options: ['Indexing', 'Isolation', 'Integrity', 'Immutability'],
    correctAnswerIndex: 1,
    explanation: 'Isolation ensures that concurrent transactions do not interfere with each other\'s intermediate state, appearing as if transactions execute sequentially.',
    tags: ['ACID', 'Transactions', 'Database Fundamentals']
  },
  {
    id: 'mcq-db-3',
    category: 'technical',
    topic: 'Database Management (SQL)',
    difficulty: 'hard',
    question: 'In database normalization, a relation is in 3NF (Third Normal Form) if it is in 2NF and:',
    options: [
      'It contains no multi-valued dependencies',
      'No non-prime attribute is transitively dependent on any candidate key',
      'Every determinant is a super key',
      'All attributes are stored as atomic JSON objects'
    ],
    correctAnswerIndex: 1,
    explanation: 'Third Normal Form (3NF) eliminates transitive functional dependencies, meaning non-key attributes must depend solely on candidate keys and not on other non-key attributes.',
    tags: ['Normalization', '3NF', 'Database Schema']
  },

  // TECHNICAL - WEB DEVELOPMENT & SYSTEM DESIGN
  {
    id: 'mcq-sys-1',
    category: 'technical',
    topic: 'System Design',
    difficulty: 'medium',
    question: 'Which strategy is used to distribute incoming web traffic across multiple server instances to improve availability and fault tolerance?',
    options: ['Database Indexing', 'Load Balancing', 'Content Delivery Network (CDN)', 'Deadlock Recovery'],
    correctAnswerIndex: 1,
    explanation: 'A Load Balancer sits in front of backend servers and routes incoming client requests across available healthy app servers using algorithms like Round Robin, Least Connections, or IP Hash.',
    tags: ['Load Balancing', 'System Design', 'Scalability']
  },
  {
    id: 'mcq-sys-2',
    category: 'technical',
    topic: 'Web Development',
    difficulty: 'easy',
    question: 'What is the main purpose of CORS (Cross-Origin Resource Sharing) in modern web browsers?',
    options: [
      'Compress HTTP responses to speed up page loading',
      'Allow or restrict web applications running at one origin to request resources from a different origin',
      'Encrypt browser cookies stored in localStorage',
      'Automatically compile TypeScript into JavaScript'
    ],
    correctAnswerIndex: 1,
    explanation: 'CORS is a browser security mechanism that uses HTTP headers to determine whether a browser should allow frontend code on origin A to access resources served by origin B.',
    tags: ['CORS', 'Web Security', 'HTTP']
  },
  {
    id: 'mcq-sys-3',
    category: 'technical',
    topic: 'System Design',
    difficulty: 'hard',
    question: 'According to the CAP Theorem, in the presence of a Network Partition (P), a distributed system MUST choose between which two properties?',
    options: [
      'Consistency (C) vs Availability (A)',
      'Concurrency (C) vs Authentication (A)',
      'Caching (C) vs Asynchrony (A)',
      'Compression (C) vs Aggregation (A)'
    ],
    correctAnswerIndex: 0,
    explanation: 'The CAP Theorem proves that a distributed data store can guarantee at most two of: Consistency, Availability, and Partition Tolerance. When network partitions inevitably occur, a system must pick between CP or AP.',
    tags: ['CAP Theorem', 'Distributed Systems', 'Architecture']
  },

  // HR & BEHAVIORAL QUESTIONS
  {
    id: 'mcq-hr-1',
    category: 'hr',
    topic: 'Behavioral & STAR Method',
    difficulty: 'easy',
    question: 'What does the acronym "STAR" stand for in structured behavioral interview responses?',
    options: [
      'Situation, Task, Action, Result',
      'Strategy, Technique, Analysis, Reaction',
      'Scenario, Target, Assessment, Resolution',
      'Skill, Training, Achievement, Reflection'
    ],
    correctAnswerIndex: 0,
    explanation: 'The STAR method (Situation, Task, Action, Result) is a structured framework for answering behavioral interview questions concisely and impactfully with real-world examples.',
    tags: ['STAR Method', 'HR Interview', 'Behavioral']
  },
  {
    id: 'mcq-hr-2',
    category: 'hr',
    topic: 'Conflict & Leadership',
    difficulty: 'medium',
    question: 'When asked "Describe a time you disagreed with a technical decision made by your manager", what is the best approach?',
    options: [
      'Explain why the manager was completely wrong and how you ignored their order',
      'Use the STAR method: describe the objective disagreement, how you respectfully voiced concerns with data, and aligned with the final team decision',
      'Say you never disagree with authority under any circumstances',
      'Complain about poor management and project deadlines'
    ],
    correctAnswerIndex: 1,
    explanation: 'Interviewers look for emotional intelligence, constructive communication, data-driven reasoning, and the ability to "disagree and commit" professionally for team unity.',
    tags: ['Conflict Resolution', 'Leadership', 'Emotional Intelligence']
  },
  {
    id: 'mcq-hr-3',
    category: 'hr',
    topic: 'Career Goals & Culture',
    difficulty: 'medium',
    question: 'When an interviewer asks "Where do you see yourself in 5 years?", what key element should your answer demonstrate?',
    options: [
      'A desire to take over the interviewer\'s current job title immediately',
      'Realistic professional growth, desire to master relevant skills, and alignment with the company\'s vision',
      'Exact salary targets and plans to switch to a competitor',
      'Vague answers about winning the lottery or traveling the world'
    ],
    correctAnswerIndex: 1,
    explanation: 'Employers want to see ambitious yet grounded career progression, continuous learning, and long-term value alignment with the organization.',
    tags: ['Career Goals', 'Culture Fit', 'HR Strategy']
  },

  // QUANTITATIVE APTITUDE & REASONING
  {
    id: 'mcq-apt-1',
    category: 'aptitude',
    topic: 'Quantitative Reasoning',
    difficulty: 'easy',
    question: 'A train 150 meters long is traveling at a speed of 54 km/hr. How long will it take to cross a pole?',
    options: ['8 seconds', '10 seconds', '12 seconds', '15 seconds'],
    correctAnswerIndex: 1,
    explanation: 'Speed in m/s = 54 × (5/18) = 15 m/s. Time to cross pole = Distance / Speed = 150m / 15m/s = 10 seconds.',
    tags: ['Speed Distance Time', 'Math', 'Aptitude']
  },
  {
    id: 'mcq-apt-2',
    category: 'aptitude',
    topic: 'Quantitative Reasoning',
    difficulty: 'medium',
    question: 'If the price of a product increases by 20% and then decreases by 20%, what is the net percentage change in price?',
    options: ['0% change', '4% increase', '4% decrease', '2% decrease'],
    correctAnswerIndex: 2,
    explanation: 'Let original price = 100. After 20% increase = 120. After 20% decrease = 120 - (0.20 × 120) = 96. Net change = 96 - 100 = -4% (4% decrease). Formula: -x²/100 = -20²/100 = -4%.',
    tags: ['Percentages', 'Profit Loss', 'Quantitative']
  },
  {
    id: 'mcq-apt-3',
    category: 'aptitude',
    topic: 'Logical Deduction',
    difficulty: 'medium',
    question: 'Find the next number in the series: 3, 5, 9, 17, 33, ?',
    options: ['49', '55', '65', '67'],
    correctAnswerIndex: 2,
    explanation: 'Differences between consecutive terms are powers of 2: (+2, +4, +8, +16, +32). Thus, 33 + 32 = 65. (Alternatively: term × 2 - 1).',
    tags: ['Number Series', 'Logical Reasoning', 'Pattern']
  },
  {
    id: 'mcq-apt-4',
    category: 'aptitude',
    topic: 'Quantitative Reasoning',
    difficulty: 'hard',
    question: 'A and B together can complete a work in 12 days. B alone can complete it in 30 days. How many days will A alone take to complete the work?',
    options: ['18 days', '20 days', '22 days', '24 days'],
    correctAnswerIndex: 1,
    explanation: 'Work done by A + B in 1 day = 1/12. Work done by B in 1 day = 1/30. Work done by A in 1 day = (1/12) - (1/30) = (5 - 2)/60 = 3/60 = 1/20. Hence, A alone takes 20 days.',
    tags: ['Time and Work', 'Quantitative', 'Aptitude']
  }
];
